<?php
require_once __DIR__ . '/../php_files/auth.php';

$user = requireRole($conn, ['unit owner']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Zeppelin Suites — Maintenance</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config={theme:{extend:{fontFamily:{sans:['DM Sans','sans-serif'],mono:['DM Mono','monospace']}}}}</script>
<style>
* { font-family: 'DM Sans', sans-serif; }
.sidebar { width:256px; transition:width 0.3s cubic-bezier(0.4,0,0.2,1),transform 0.3s cubic-bezier(0.4,0,0.2,1); background:rgba(255,255,255,0.92); backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px); }
.sidebar.collapsed { width:68px; }
@media (max-width:767px) { .sidebar { transform:translateX(-100%); position:fixed; z-index:50; height:100vh; width:256px !important; } .sidebar.open { transform:translateX(0); } }
.main-wrapper { margin-left:256px; transition:margin-left 0.3s cubic-bezier(0.4,0,0.2,1); }
.main-wrapper.sidebar-collapsed { margin-left:68px; }
@media (max-width:767px) { .main-wrapper { margin-left:0 !important; } }
.sidebar-logo { transition:opacity 0.2s ease,width 0.2s ease; }
.sidebar.collapsed .sidebar-logo { opacity:0; width:0; overflow:hidden; pointer-events:none; }
.overlay { display:none; pointer-events:none; }
.overlay.show { display:block; pointer-events:auto; }
.sidebar-link { position:relative; transition:all 0.18s ease; white-space:nowrap; overflow:hidden; }
.sidebar-link.active { background:#0f172a; color:#fff; }
.sidebar-link.active .nav-icon { color:#60a5fa; }
.sidebar-link:not(.active):hover { background:#eff6ff; color:#1d4ed8; }
.sidebar-link:not(.active):hover .nav-icon { color:#3b82f6; }
.sidebar.collapsed .nav-label,.sidebar.collapsed .notice-section { display:none; }
.sidebar.collapsed .sidebar-link { justify-content:center; padding-left:0; padding-right:0; }
.sidebar.collapsed .collapse-icon { transform:rotate(180deg); }
.sidebar.collapsed .sidebar-link:hover::after { content:attr(data-tooltip); position:absolute; left:calc(100% + 10px); top:50%; transform:translateY(-50%); background:#0f172a; color:#fff; font-size:12px; padding:5px 10px; border-radius:8px; white-space:nowrap; z-index:999; box-shadow:0 4px 16px rgba(0,0,0,0.18); pointer-events:none; }
.collapse-icon { transition:transform 0.3s ease; }
.profile-dropdown { opacity:0; visibility:hidden; transform:translateY(-6px); transition:all 0.2s cubic-bezier(0.4,0,0.2,1); }
.profile-dropdown.open { opacity:1; visibility:visible; transform:translateY(0); }
/* row hover handled by Tailwind group/group-hover */
.modal-backdrop { opacity:0; visibility:hidden; transition:opacity 0.22s ease,visibility 0.22s ease; }
.modal-backdrop.open { opacity:1; visibility:visible; }
.modal-card { transform:translateY(12px) scale(0.98); transition:transform 0.22s cubic-bezier(0.4,0,0.2,1); }
.modal-backdrop.open .modal-card { transform:translateY(0) scale(1); }
.zep-input:focus { outline:none; border-color:#0f172a; box-shadow:0 0 0 3px rgba(15,23,42,0.07); }
.zep-select:focus { outline:none; border-color:#0f172a; box-shadow:0 0 0 3px rgba(15,23,42,0.07); }
::-webkit-scrollbar { width:4px; height:4px; }
::-webkit-scrollbar-track { background:#f1f5f9; }
::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:4px; }
.btn-press { transition:all 0.15s ease; }
.btn-press:active { transform:scale(0.95); }
.glass-header { background:rgba(255,255,255,0.85); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px); }
.main-scroll { height:calc(100vh - 65px); overflow-y:auto; }
</style>
</head>
<body class="bg-slate-50 text-slate-800 overflow-hidden">

<div class="overlay fixed inset-0 bg-transparent z-40" id="overlay" onclick="closeMobileSidebar()"></div>

<!-- SIDEBAR -->
<aside class="sidebar fixed left-0 top-0 h-full border-r border-slate-100/80 flex flex-col z-50 md:z-40 shadow-2xl md:shadow-none" id="sidebar">
  <div class="px-4 py-5 border-b border-slate-100 flex items-center justify-between shrink-0">
    <a href="overview.html" class="sidebar-logo shrink-0 flex items-center">
      <img src="../images/zeppelin-logo.png" alt="Zeppelin Suites" class="h-10 w-auto object-contain" onerror="this.outerHTML='<span class=\'font-bold text-slate-900 text-sm\'>ZEPPELIN SUITES</span>'">
    </a>
    <button onclick="toggleCollapse()" class="hidden md:flex btn-press p-1.5 rounded-lg hover:bg-slate-100 transition-colors active:scale-95 shrink-0 ml-1">
      <svg class="collapse-icon w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/></svg>
    </button>
  </div>
  <nav class="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto overflow-x-hidden">
    <a href="overview.php" data-tooltip="Overview" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
      <span class="nav-label">Overview</span>
    </a>
    <a href="ownersUnit.php" data-tooltip="Units" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V9a2 2 0 00-2-2h-3V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14m0 0H3m3 0h14m-7 0v-4h2v4"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 9h1m4 0h1M9 13h1m4 0h1"/></svg>
      <span class="nav-label">Units</span>
    </a>
    <a href="tenants.php" data-tooltip="Tenants" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      <span class="nav-label">Tenants</span>
    </a>
    <a href="ownersMaintenance.php" data-tooltip="Maintenance" class="sidebar-link active flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      <span class="nav-label">Maintenance</span>
    </a>
    <a href="ownersUnitReservations.php" data-tooltip="Reservations" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
      <span class="nav-label">Reservations</span>
    </a>
    <a href="ownersReservations.php" data-tooltip="Reservations" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
      <span class="nav-label">Inquiries</span>
    </a>
  </nav>
</aside>

<!-- MAIN WRAPPER -->
<div class="main-wrapper h-screen flex flex-col" id="mainWrapper">
  <header class="glass-header border-b border-slate-100/80 px-4 md:px-6 py-3.5 flex items-center gap-4 shrink-0 z-30">
    <button class="md:hidden p-2 rounded-xl hover:bg-slate-100 transition-colors btn-press active:scale-95" onclick="openMobileSidebar()">
      <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
    </button>
    <div class="relative flex-1 max-w-sm">
      <svg class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
     <input
        type="text"
        id="searchInput"
        placeholder="Search maintenance requests..."
        oninput="filterTable()"
        class="zep-input w-full pl-10 pr-4 py-2 bg-slate-50/80 border border-slate-200 rounded-full text-sm transition-all">
  </div>
    <div class="flex items-center gap-2 ml-auto">
      <button class="relative p-2 rounded-xl hover:bg-slate-100 transition-colors btn-press active:scale-95">
        <svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
        <span class="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white"></span>
      </button>
      <div class="relative" id="profileWrapper">
        <button onclick="toggleProfile()" class="flex items-center gap-2.5 pl-3 border-l border-slate-200 hover:bg-slate-50 rounded-xl px-3 py-1.5 transition-all btn-press active:scale-95">
          <div class="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white text-xs font-bold shrink-0">
            <?= htmlspecialchars($user['initial'] ?? 'U') ?>
          </div>

          <div class="hidden sm:block text-left">
            <p class="text-sm font-semibold text-slate-800 leading-none">
              <?= htmlspecialchars($user['full_name'] ?? 'Unit Owner') ?>
            </p>
            <p class="text-xs text-slate-400 mt-0.5">Unit Owner</p>
          </div>
          <svg class="w-3.5 h-3.5 text-slate-400 transition-transform duration-200" id="profileChevron" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div class="profile-dropdown absolute right-0 top-full mt-2 w-48 bg-white backdrop-blur-xl border border-slate-200 rounded-2xl shadow-2xl py-2 z-50" id="profileDropdown">
          <a href="../php_files/logout_session.php" class="flex items-center gap-3 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 transition-colors rounded-xl mx-1">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
            Sign out
          </a>    
        </div>
      </div>
    </div>
  </header>

  <div class="main-scroll p-4 md:p-6 space-y-6">
    <div class="max-w-screen-xl mx-auto space-y-6">
      <?php if (!empty($_SESSION['success_message'])): ?>
        <div class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
          <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
        </div>
      <?php endif; ?>

      <?php if (!empty($_SESSION['error_message'])): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
          <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
        </div>
      <?php endif; ?>
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-bold text-slate-900">Maintenance Request</h1>
        <button onclick="openCreateModal()" class="btn-press bg-slate-900 hover:bg-slate-700 text-white text-sm font-semibold px-5 py-2.5 rounded-full transition-all active:scale-95 flex items-center gap-2">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
          Create Request
        </button>
      </div>

      <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
                    <table class="w-full text-sm" id="mainTable">
            <thead>
              <tr class="border-b border-slate-100 bg-slate-50/60">
                <th class="text-left px-4 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Request ID</th>
                <th class="text-left px-4 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Unit No</th>
                <th class="text-left px-4 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Category</th>
                <th class="text-left px-4 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Issue</th>
                <th class="text-left px-4 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Date Submitted</th>
                <th class="text-left px-4 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Status</th>
                <th class="px-4 py-3.5 w-20"></th>
              </tr>
            </thead>
            <tbody id="mainBody">
              <?php require_once __DIR__ . '/ActionsUOP/getOwnerMaintenanceRequests.php'; ?>
            </tbody>
          </table>
        </div>
        <div class="flex items-center justify-between px-5 py-3.5 border-t border-slate-100">
          <p class="text-xs text-slate-400">Showing 2 requests</p>
          <div class="flex items-center gap-1">
            <button class="btn-press w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 transition-all active:scale-95"><svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg></button>
            <button class="btn-press w-8 h-8 flex items-center justify-center rounded-lg border bg-slate-900 border-slate-900 text-white text-xs font-bold active:scale-95">1</button>
            <button class="btn-press w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 transition-all active:scale-95"><svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg></button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- VIEW MODAL -->
<div class="modal-backdrop fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4" id="viewModal" onclick="handleBackdropClick(event,'viewModal')">
  <div class="modal-card bg-white rounded-lg shadow-2xl w-full max-w-md border border-slate-100 overflow-hidden">
    <div class="bg-slate-900 px-6 py-4 flex items-center justify-between">
      <div>
        <h2 class="text-base font-bold text-white">Maintenance Request</h2>
        <p class="text-xs text-slate-400 mt-0.5" id="mViewId">—</p>
      </div>
      <button onclick="closeModal('viewModal')" class="btn-press p-1.5 rounded-lg hover:bg-white/10 transition-colors active:scale-95">
        <svg class="w-4 h-4 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
    </div>
    <div class="p-5 max-h-[70vh] overflow-y-auto">
      <div class="grid grid-cols-[110px_minmax(0,1fr)] gap-x-4 gap-y-3 items-start">
        <p class="text-xs font-medium text-slate-500">Unit:</p>
        <p class="text-xs font-semibold text-slate-900" id="mViewUnit">—</p>

        <p class="text-xs font-medium text-slate-500">Priority:</p>
        <p class="text-xs text-slate-700" id="mViewPriority">—</p>

        <p class="text-xs font-medium text-slate-500">Category:</p>
        <p class="text-xs text-slate-700" id="mViewCategory">—</p>

        <p class="text-xs font-medium text-slate-500">Status:</p>
        <span class="justify-self-start text-xs font-semibold px-2.5 py-1 rounded-md border" id="mViewStatus">—</span>

        <p class="text-xs font-medium text-slate-500">Date Submitted:</p>
        <p class="text-xs text-slate-600" id="mViewDate" style="font-family:'DM Mono',monospace">—</p>

        <p class="text-xs font-medium text-slate-500">Resolved Date:</p>
        <p class="text-xs text-slate-600" id="mViewResolvedDate" style="font-family:'DM Mono',monospace">—</p>
      </div>

      <div class="border-t border-slate-200 mt-4 pt-4 grid grid-cols-[110px_minmax(0,1fr)] gap-x-4 gap-y-4 items-start">
        <p class="text-xs font-medium text-slate-500">Issue:</p>
        <p class="text-xs font-medium text-slate-800" id="mViewIssue">—</p>

        <p class="text-xs font-medium text-slate-500">Description:</p>
        <p class="text-xs text-slate-600 leading-relaxed" id="mViewDesc">—</p>

        <p class="text-xs font-medium text-slate-500">Admin Remarks:</p>
        <p class="text-xs text-slate-600 leading-relaxed" id="mViewRemarks">—</p>

        <p class="text-xs font-medium text-slate-500">Photos:</p>
        <div class="grid grid-cols-2 gap-2" id="mViewPhotos"></div>
      </div>
    </div>
    <div class="flex items-center justify-end gap-2 px-6 py-4 border-t border-slate-100 bg-slate-50/60">
      <button onclick="closeModal('viewModal')" class="btn-press px-4 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-100 transition-all active:scale-95">Close</button>
   </div>
  </div>
</div>

<!-- CREATE REQUEST MODAL -->
<div class="modal-backdrop fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4" id="createModal" onclick="handleBackdropClick(event,'createModal')">
  <form 
    action="ActionsUOP/submitMaintenanceRequest.php" 
    method="POST" 
    enctype="multipart/form-data"
    class="modal-card bg-white rounded-2xl shadow-2xl w-full max-w-md border border-slate-100 overflow-hidden"
    onclick="event.stopPropagation()">

    <div class="bg-slate-900 px-6 py-4 flex items-center justify-between">
      <div>
        <h2 class="text-base font-bold text-white">Create Maintenance Request</h2>
        <p class="text-xs text-slate-400 mt-0.5">Submit a maintenance concern for your unit.</p>
      </div>

      <button type="button" onclick="closeModal('createModal')" class="btn-press p-1.5 rounded-lg hover:bg-white/10 transition-colors active:scale-95">
        <svg class="w-4 h-4 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>

    <div class="p-6 space-y-4">
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
          Unit <span class="text-red-500">*</span>
        </label>

        <select 
          name="unit_id" 
          id="crUnit"
          required
          class="zep-select w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm cursor-pointer transition-all">
          <option value="">Select affected unit</option>
          <?php require_once __DIR__ . '/ActionsUOP/getOwnerUnitsOptions.php'; ?>
        </select>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
          Subject <span class="text-red-500">*</span>
        </label>
        <input 
          type="text" 
          name="subject"
          id="crSubject" 
          required
          placeholder="Brief description of the issue" 
          class="zep-input w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm transition-all">
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
            Category <span class="text-red-500">*</span>
          </label>

          <select 
            name="category"
            id="crCategory" 
            required
            class="zep-select w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm cursor-pointer transition-all">
            <option value="">Select category</option>
            <option value="Plumbing">Plumbing</option>
            <option value="Electrical">Electrical</option>
            <option value="Cleaning">Cleaning</option>
            <option value="Fixture">Fixture</option>
            <option value="Structural">Structural</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
            Priority <span class="text-red-500">*</span>
          </label>

          <select 
            name="priority"
            id="crPriority" 
            required
            class="zep-select w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm cursor-pointer transition-all">
            <option value="normal">Normal</option>
            <option value="low">Low</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
          Description <span class="text-red-500">*</span>
        </label>

        <textarea 
          name="description"
          id="crDesc" 
          rows="4" 
          required
          placeholder="Describe the issue in detail..." 
          class="zep-input w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm transition-all resize-none"></textarea>
      </div>

      <!-- UPLOAD PHOTOS -->
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
          Upload Photos
        </label>

        <label 
          for="maintenancePhotos" 
          class="upload-zone w-full min-h-[140px] rounded-xl flex flex-col items-center justify-center gap-3 cursor-pointer border border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 transition-all">

          <svg class="w-9 h-9 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
          </svg>

          <div class="text-center">
            <p class="text-base font-bold text-slate-800">Click to upload or drag &amp; drop</p>
            <p class="text-sm text-slate-500 mt-1">JPG, PNG, WEBP up to 5MB each</p>
            <p class="text-xs text-slate-400 mt-1">Maximum of 5 photos</p>
          </div>

          <span id="maintenanceUploadFileName" class="text-sm text-emerald-600 font-semibold hidden"></span>

          <input 
            type="file" 
            name="maintenance_photos[]" 
            id="maintenancePhotos"
            accept=".jpg,.jpeg,.png,.webp"
            multiple
            class="hidden"
            onchange="handleMaintenanceUpload(this)">
        </label>
      </div>
    </div>

    <div class="flex items-center justify-end gap-2 px-6 py-4 border-t border-slate-100 bg-slate-50/60">
      <button 
        type="button"
        onclick="closeModal('createModal')" 
        class="btn-press px-4 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-100 transition-all active:scale-95">
        Cancel
      </button>

      <button 
        type="submit"
        class="btn-press bg-slate-900 hover:bg-slate-700 text-white text-sm font-bold px-6 py-2 rounded-xl tracking-widest transition-all active:scale-95">
        SEND
      </button>
    </div>
  </form>
</div>

<script>
  let sidebarCollapsed = false;
  function toggleCollapse() {
    sidebarCollapsed = !sidebarCollapsed;
    document.getElementById('sidebar').classList.toggle('collapsed', sidebarCollapsed);
    document.getElementById('mainWrapper').classList.toggle('sidebar-collapsed', sidebarCollapsed);
  }
  function openMobileSidebar() { document.getElementById('sidebar').classList.add('open'); document.getElementById('overlay').classList.add('show'); }
  function closeMobileSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('overlay').classList.remove('show'); }
  function toggleProfile() {
    const dd = document.getElementById('profileDropdown'), ch = document.getElementById('profileChevron');
    const open = dd.classList.toggle('open'); ch.style.transform = open ? 'rotate(180deg)' : '';
  }
  document.addEventListener('click', e => {
    const w = document.getElementById('profileWrapper');
    if (w && !w.contains(e.target)) { document.getElementById('profileDropdown').classList.remove('open'); document.getElementById('profileChevron').style.transform = ''; }
  });
  function openViewModal(button) {
    document.getElementById('mViewId').textContent = button.dataset.id || '—';
    document.getElementById('mViewUnit').textContent = button.dataset.unit || '—';
    document.getElementById('mViewPriority').textContent = button.dataset.priority || '—';
    document.getElementById('mViewCategory').textContent = button.dataset.category || '—';
    document.getElementById('mViewDate').textContent = button.dataset.date || '—';
    document.getElementById('mViewResolvedDate').textContent = button.dataset.resolvedDate || 'Not yet resolved';
    document.getElementById('mViewIssue').textContent = button.dataset.issue || '—';
    document.getElementById('mViewDesc').textContent = button.dataset.description || 'No description provided.';
    document.getElementById('mViewRemarks').textContent = button.dataset.remarks || 'No admin remarks yet.';

    const badge = document.getElementById('mViewStatus');
    const status = button.dataset.status || 'Pending';
    const colors = {
      'pending': 'bg-amber-50 text-amber-700 border-amber-200',
      'in progress': 'bg-blue-50 text-blue-700 border-blue-200',
      'resolved': 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'cancelled': 'bg-red-50 text-red-700 border-red-200'
    };

    badge.textContent = status;
    badge.className = 'text-xs font-semibold px-2.5 py-1 rounded-full border ' +
      (colors[status.toLowerCase()] || 'bg-slate-50 text-slate-600 border-slate-200');

    const container = document.getElementById('mViewPhotos');
    container.innerHTML = '';

    const photos = button.dataset.photos
      ? button.dataset.photos.split(',')
      : [];

    if (photos.length === 0) {
      const message = document.createElement('p');
      message.textContent = 'No photos uploaded.';
      message.className = 'col-span-2 text-sm text-slate-400';
      container.appendChild(message);
    } else {
      photos.forEach(path => {
        const link = document.createElement('a');
        link.href = path.trim();
        link.target = '_blank';
        link.rel = 'noopener noreferrer';

        const image = document.createElement('img');
        image.src = path.trim();
        image.alt = 'Maintenance request photo';
        image.className = 'w-full h-28 object-cover rounded-md border border-slate-200 hover:opacity-90';

        link.appendChild(image);
        container.appendChild(link);
      });
    }

    document.getElementById('viewModal').classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function openCreateModal() {
    document.getElementById('createModal').classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function handleMaintenanceUpload(input) {
  const fileNameDisplay = document.getElementById('maintenanceUploadFileName');

  if (!fileNameDisplay) return;

  if (!input.files || input.files.length === 0) {
    fileNameDisplay.classList.add('hidden');
    fileNameDisplay.textContent = '';
    return;
  }

  if (input.files.length > 5) {
    alert('You may upload up to 5 photos only.');
    input.value = '';
    fileNameDisplay.classList.add('hidden');
    fileNameDisplay.textContent = '';
    return;
  }

  fileNameDisplay.textContent = input.files.length === 1
    ? input.files[0].name
    : `${input.files.length} photos selected`;

  fileNameDisplay.classList.remove('hidden');
}
  function closeModal(id) { document.getElementById(id).classList.remove('open'); document.body.style.overflow = ''; }
  function handleBackdropClick(e, id) { if (e.target === document.getElementById(id)) closeModal(id); }
  function filterTable() {
    const q = document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('#mainBody tr').forEach(r => { r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none'; });
  }

</script>
</body>
</html>
