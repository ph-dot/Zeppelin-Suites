<?php 
require_once '../php_files/auth.php'; 
require_once '../php_files/db.php'; 

$userData = requireRole($conn, ['unit owner']); 
$owner_id = (int)$userData['user_id']; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Zeppelin Suites Admin — Reservations</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config={theme:{extend:{fontFamily:{sans:['DM Sans','sans-serif'],mono:['DM Mono','monospace']}}}}</script>
<style>
* { font-family: 'DM Sans', sans-serif; }
.sidebar { width:256px; transition:width 0.3s cubic-bezier(0.4,0,0.2,1),transform 0.3s cubic-bezier(0.4,0,0.2,1); background:rgba(255,255,255,0.92); backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px); }
.sidebar.collapsed { width:68px; }
@media (max-width:767px) { .sidebar { transform:translateX(-100%); position:fixed; z-index:50; height:100vh; width:256px !important; } .sidebar.open { transform:translateX(0); } }
.main-wrapper { margin-left:256px; transition:margin-left 0.3s cubic-bezier(0.4,0,0.2,1); }
.main-wrapper.sidebar-collapsed { margin-left:68px; }
@media (max-width:767px) { .main-wrapper { margin-left:0 !important; } }
.overlay { display:none; pointer-events:none; }
.overlay.show { display:block; pointer-events:auto; }
.sidebar-logo { transition:opacity 0.2s ease,width 0.2s ease; }
.sidebar.collapsed .sidebar-logo { opacity:0; width:0; overflow:hidden; pointer-events:none; }
.sidebar-link { position:relative; transition:all 0.18s ease; white-space:nowrap; overflow:hidden; }
.sidebar-link.active { background:#0f172a; color:#fff; }
.sidebar-link.active .nav-icon { color:#60a5fa; }
.sidebar-link:not(.active):hover { background:#eff6ff; color:#1d4ed8; }
.sidebar-link:not(.active):hover .nav-icon { color:#3b82f6; }
.sidebar.collapsed .nav-label,.sidebar.collapsed .nav-badge,.sidebar.collapsed .notice-section { display:none; }
.sidebar.collapsed .sidebar-link { justify-content:center; padding-left:0; padding-right:0; }
.sidebar.collapsed .collapse-icon { transform:rotate(180deg); }
.sidebar.collapsed .sidebar-link:hover::after { content:attr(data-tooltip); position:absolute; left:calc(100% + 10px); top:50%; transform:translateY(-50%); background:#0f172a; color:#fff; font-size:12px; padding:5px 10px; border-radius:8px; white-space:nowrap; z-index:999; box-shadow:0 4px 16px rgba(0,0,0,0.18); pointer-events:none; }
.collapse-icon { transition:transform 0.3s ease; }
.notice-panel { max-height:0; overflow:hidden; opacity:0; transition:max-height 0.3s ease,opacity 0.3s ease; }
.notice-panel.open { max-height:120px; opacity:1; }
.notice-chevron { transition:transform 0.3s ease; }
.notice-chevron.rotated { transform:rotate(180deg); }
.profile-dropdown { 
  opacity:0; 
  visibility:hidden; 
  transform:translateY(-6px); 
  transition: all 0.2s cubic-bezier(0.4,0,0.2,1); 
}
.profile-dropdown:not(.hidden) { 
  opacity:1; 
  visibility:visible; 
  transform:translateY(0); 
}
.stat-card { background:linear-gradient(135deg,#ffffff 0%,#f8fafc 100%); transition:transform 0.22s ease,box-shadow 0.22s ease,border-color 0.22s ease; cursor:pointer; }
.stat-card:hover { transform:translateY(-4px); box-shadow:0 20px 40px rgba(0,0,0,0.10); border-color:#0f172a; }
.res-row { transition:background 0.15s ease; }
.res-row:hover { background:#f1f5f9; }
.res-row .res-name { transition:color 0.15s ease; }
.res-row:hover .res-name { color:#1d4ed8; }
.view-btn { opacity:0; transform:translateX(6px); transition:opacity 0.18s ease,transform 0.18s ease; }
.res-row:hover .view-btn { opacity:1; transform:translateX(0); }
::-webkit-scrollbar { width:4px; height:4px; }
::-webkit-scrollbar-track { background:#f1f5f9; }
::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:4px; }
::-webkit-scrollbar-thumb:hover { background:#94a3b8; }
.btn-press { transition:all 0.15s ease; }
.btn-press:active { transform:scale(0.95); }
.zep-input:focus { outline:none; border-color:#0f172a; box-shadow:0 0 0 3px rgba(15,23,42,0.07); }
.zep-select:focus { outline:none; border-color:#0f172a; box-shadow:0 0 0 3px rgba(15,23,42,0.07); }
.glass-header { background:rgba(255,255,255,0.85); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px); }
.main-scroll { height:calc(100vh - 65px); overflow-y:auto; }
/* Modal */
.modal-backdrop { opacity:0; visibility:hidden; transition:opacity 0.25s ease,visibility 0.25s ease; }
.modal-backdrop.open { opacity:1; visibility:visible; }
.modal-card { transform:translateY(16px) scale(0.97); transition:transform 0.25s cubic-bezier(0.4,0,0.2,1); }
.modal-backdrop.open .modal-card { transform:translateY(0) scale(1); }
</style>
</head>
<body class="bg-slate-50 text-slate-800 overflow-hidden">

<div class="overlay fixed inset-0 bg-transparent z-40" id="overlay" onclick="closeMobileSidebar()"></div>

<!-- SIDEBAR -->
<aside class="sidebar fixed left-0 top-0 h-full border-r border-slate-100/80 flex flex-col z-50 md:z-40 shadow-2xl md:shadow-none" id="sidebar">
  <div class="px-4 py-5 border-b border-slate-100 flex items-center justify-between shrink-0">
    <a href="overview.html" class="sidebar-logo shrink-0 flex items-center">
      <img src="../images/zeppelin-logo.png" alt="Zeppelin Suites" class="h-10 w-auto object-contain" onerror="this.outerHTML='<span class=\'font-bold text-slate-900 text-sm\'>ZEPPELIN SUITES</span>'">
    </a>
    <button onclick="toggleCollapse()" class="hidden md:flex btn-press p-1.5 rounded-lg hover:bg-slate-100 transition-colors active:scale-95 shrink-0 ml-1">
      <svg class="collapse-icon w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7"/></svg>
    </button>
  </div>
  <nav class="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto overflow-x-hidden">
  <a href="overview.php" data-tooltip="Overview" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
      <span class="nav-label">Overview</span>
    </a>
    <a href="ownersReservations.php" data-tooltip="Reservations" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
      <span class="nav-label">Inquiries</span>
    </a>
     <a href="ownersUnitReservations.php" data-tooltip="Reservations" class="sidebar-link active flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
      <span class="nav-label">Reservations</span>
    </a>
    <a href="ownersBookingCalendar.php" data-tooltip="Booking Calendar" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
      <span class="nav-label">Booking Calendar</span>
    </a>

    <a href="ownersUnit.php" data-tooltip="Units" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V9a2 2 0 00-2-2h-3V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14m0 0H3m3 0h14m-7 0v-4h2v4"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 9h1m4 0h1M9 13h1m4 0h1"/></svg>
      <span class="nav-label">Units</span>
    </a>
    <a href="tenants.php" data-tooltip="Tenants" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      <span class="nav-label">Tenants</span>
    </a>
    <a href="ownersMaintenance.php" data-tooltip="Maintenance" class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500">
      <svg class="nav-icon w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      <span class="nav-label">Maintenance</span>
    </a>
  </nav>
</aside>

<div class="main-wrapper h-screen flex flex-col" id="mainWrapper">
   <header class="glass-header border-b border-slate-100/80 px-4 md:px-6 py-3.5 flex items-center gap-4 shrink-0 z-30">
    <button class="md:hidden p-2 rounded-xl hover:bg-slate-100 transition-colors btn-press active:scale-95" onclick="openMobileSidebar()">
      <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
    </button>
    <div class="relative flex-1 max-w-sm">
      <svg class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
      <input type="text" placeholder="Search..." class="zep-input w-full pl-10 pr-4 py-2 bg-slate-50/80 border border-slate-200 rounded-full text-sm transition-all">
    </div>
    <div class="flex items-center gap-2 ml-auto">
      <button class="relative p-2 rounded-xl hover:bg-slate-100 transition-colors btn-press active:scale-95">
        <svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
        <span class="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white"></span>
      </button>
      <div class="relative" id="profileWrapper">
        <button onclick="toggleProfile()" class="flex items-center gap-2.5 pl-3 border-l border-slate-200 hover:bg-slate-50 rounded-xl px-3 py-1.5 transition-all btn-press active:scale-95">
          <div class="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white text-xs font-bold shrink-0">
            <?= htmlspecialchars($user['initial'] ?? 'U') ?>
          </div>

          <div class="hidden sm:block text-left">
            <p class="text-sm font-semibold text-slate-800 leading-none">
              <?= htmlspecialchars($user['full_name'] ?? 'Unit Owner') ?>
            </p>
            <p class="text-xs text-slate-400 mt-0.5">Unit Owner</p>
          </div>
          <svg class="w-3.5 h-3.5 text-slate-400 transition-transform duration-200" id="profileChevron" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div class="profile-dropdown absolute right-0 top-full mt-2 w-48 bg-white backdrop-blur-xl border border-slate-200 rounded-2xl shadow-2xl py-2 z-50" id="profileDropdown">
          <a href="../php_files/logout_session.php" class="flex items-center gap-3 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 transition-colors rounded-xl mx-1">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
            Sign out
          </a>    
        </div>
      </div>
    </div>
  </header>

  <div id="logoutModal" class="fixed inset-0 bg-black/50 z-[999] hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl p-6 w-full max-w-sm border shadow-xl">
      <h3 class="text-lg font-bold text-slate-900 mb-2">Sign out?</h3>
      <p class="text-sm text-slate-600 mb-6">Are you sure you want to logout?</p>
      <div class="flex gap-3 justify-end">
        <button onclick="hideModal()" class="px-4 py-2 text-sm hover:bg-slate-50 rounded-lg">Cancel</button>
        <button onclick="doLogout()" class="px-4 py-2 text-sm text-white bg-red-500 hover:bg-red-600 rounded-lg">Logout</button>
      </div>
    </div>
  </div>


  <main class="main-scroll p-4 md:p-6 space-y-6">
    <div class="max-w-screen-2xl mx-auto space-y-6">

      <!-- Page header -->
      <div class="flex items-center justify-between flex-wrap gap-3">
        <h1 class="text-xl font-bold text-slate-900">Reservations</h1>
        <div class="flex items-center gap-2">
          <button class="btn-press px-4 py-2 text-sm font-semibold border border-slate-200 text-slate-600 rounded-full hover:bg-slate-50 transition-all active:scale-95">
            <svg class="w-4 h-4 inline-block mr-1.5 -mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/></svg>
            Filter
          </button>
          <button class="btn-press bg-slate-900 hover:bg-slate-700 active:scale-95 text-white text-sm font-semibold px-4 py-2 rounded-full transition-all">
            + Add Reservation
          </button>
        </div>
      </div>

      <!-- Table -->
      <div class="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
          <table class="w-full text-sm" id="resTable">
            <thead>
              <tr class="border-b border-slate-100 bg-slate-50/60">
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Res. #</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Client</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Unit</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Transaction</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Amount</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Payment</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Reservation</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">Submitted</th>
                <th class="px-4 py-3 w-16"></th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-50" id="resBody">
              <?php require_once __DIR__ . '/ActionsUOP/getOwnersUnitReservations.php'; ?>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <div class="flex items-center justify-between px-5 py-3.5 border-t border-slate-100 flex-wrap gap-3">
          <p class="text-xs text-slate-500">Showing <span class="font-semibold text-slate-700">1–4</span> of <span class="font-semibold text-slate-700">4</span> reservations</p>
          <div class="flex items-center gap-1">
            <button class="btn-press w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 transition-all active:scale-95"><svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg></button>
            <button class="btn-press w-8 h-8 flex items-center justify-center rounded-lg border bg-slate-900 border-slate-900 text-white text-xs font-bold active:scale-95">1</button>
            <button class="btn-press w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 transition-all active:scale-95"><svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg></button>
          </div>
        </div>
      </div>

    </div>
  </main>
</div><!-- /main-wrapper -->

<!-- ── EDIT / VIEW RESERVATION MODAL ──────────────────── -->
<!-- VIEW RESERVATION MODAL -->
<div id="editModalBackdrop" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 px-4">
  <div class="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden">

    <!-- HEADER -->
    <div class="bg-slate-900 px-6 py-4 flex items-center justify-between">
      <div>
        <h2 class="text-xl font-bold text-white">Reservation Details</h2>
        <p id="editModalMeta" class="text-sm text-slate-300 mt-1">Reservation information</p>
      </div>

      <button 
        type="button"
        onclick="closeEditModal()"
        class="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all">
        ×
      </button>
    </div>

    <!-- BODY -->
    <div class="p-6 overflow-y-auto max-h-[70vh] space-y-6">

      <div class="p-6 overflow-y-auto max-h-[70vh] space-y-6 bg-slate-50">

  <!-- TOP SUMMARY -->
  <div class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
    <div class="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
      <div>
        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Reservation</p>
        <h3 id="view_client_name" class="text-xl font-bold text-slate-900">Client Name</h3>
        <p id="view_unit" class="text-sm text-slate-500 mt-1">Unit</p>
      </div>

      <div class="flex flex-wrap gap-2">
        <span id="view_payment_status" class="text-xs font-bold px-3 py-1.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
          Payment Status
        </span>

        <span id="view_reservation_status" class="text-xs font-bold px-3 py-1.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
          Reservation Status
        </span>
      </div>
    </div>
  </div>

  <!-- CLIENT + UNIT -->
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
    <!-- CLIENT CARD -->
    <section class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
      <div class="flex items-center gap-2 mb-4">
        <div class="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center">
          <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14c-4.418 0-8 2.015-8 4.5V20h16v-1.5c0-2.485-3.582-4.5-8-4.5z"/>
          </svg>
        </div>
        <h3 class="text-sm font-bold text-slate-900 uppercase tracking-wide">Client Information</h3>
      </div>

      <div class="space-y-3">
        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Full Name</p>
          <p id="ef_name" class="text-sm font-semibold text-slate-800 mt-1">-</p>
        </div>

        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Email</p>
          <p id="ef_email" class="text-sm text-slate-700 mt-1 break-all">-</p>
        </div>

        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Contact</p>
          <p id="ef_contact" class="text-sm text-slate-700 mt-1">-</p>
        </div>

        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Inquiry Type</p>
          <p id="ef_inquiry_type" class="text-sm text-slate-700 mt-1">-</p>
        </div>
      </div>
    </section>

    <!-- UNIT CARD -->
    <section class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
      <div class="flex items-center gap-2 mb-4">
        <div class="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center">
          <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 21h18M5 21V7l8-4v18M19 21V11l-6-4"/>
          </svg>
        </div>
        <h3 class="text-sm font-bold text-slate-900 uppercase tracking-wide">Unit Information</h3>
      </div>

      <div class="space-y-3">
        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Unit</p>
          <p id="ef_unit" class="text-sm font-semibold text-slate-800 mt-1">-</p>
        </div>

        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Unit Owner</p>
          <p id="ef_owner" class="text-sm text-slate-700 mt-1">-</p>
        </div>

        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Owner Email</p>
          <p id="ef_owner_email" class="text-sm text-slate-700 mt-1 break-all">-</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Transaction</p>
            <p id="ef_transaction_type" class="text-sm text-slate-700 mt-1">-</p>
          </div>

          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Reservation Type</p>
            <p id="ef_reservation_type" class="text-sm text-slate-700 mt-1">-</p>
          </div>
        </div>

        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Resident Type</p>
          <p id="ef_resident_type" class="text-sm text-slate-700 mt-1">-</p>
        </div>
      </div>
    </section>

  </div>

  <!-- PAYMENT INFO + PAYMENT VERIFICATION -->
  <section class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
    <div class="flex items-center justify-between gap-4 mb-5">
      <div class="flex items-center gap-2">
        <div class="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center">
          <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-2m0-6h4v6h-4m0-6v6"/>
          </svg>
        </div>
        <div>
          <h3 class="text-sm font-bold text-slate-900 uppercase tracking-wide">Payment Information</h3>
          <p class="text-xs text-slate-500 mt-0.5">Verify payment first before requirement tracking.</p>
        </div>
      </div>

      <a 
        id="ef_payment_proof" 
        href="#" 
        target="_blank"
        class="inline-flex items-center justify-center px-4 py-2 bg-blue-50 border border-blue-200 rounded-xl text-xs font-bold text-blue-700 hover:bg-blue-100 transition-all">
        View Proof
      </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Price Basis</p>
        <p id="ef_price_basis" class="text-base font-bold text-slate-900 mt-1">-</p>
      </div>

      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Selected</p>
        <p id="ef_payment_percentage" class="text-base font-bold text-slate-900 mt-1">-</p>
      </div>

      <div class="bg-slate-900 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Required Amount</p>
        <p id="ef_required_amount" class="text-lg font-bold text-white mt-1">-</p>
      </div>

      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Method</p>
        <p id="ef_payment_method" class="text-base font-bold text-slate-900 mt-1">-</p>
      </div>
    </div>

    <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">GCash Reference Number</p>
        <p id="ef_payment_reference" class="text-sm font-semibold text-slate-800 mt-1" style="font-family:'DM Mono',monospace">-</p>
      </div>

      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Payment Status</p>
        <p id="verify_payment_status" class="text-sm font-bold text-amber-700 mt-1">Pending Review</p>
      </div>
    </div>

    <div id="paymentDecisionDisplay" class="hidden mt-5 rounded-xl border px-4 py-3">
      <p class="text-xs font-bold uppercase tracking-wide mb-1" id="paymentDecisionLabel">
        Payment Decision
      </p>
      <p class="text-sm font-semibold" id="paymentDecisionText">
        -
      </p>
    </div>

    <div class="mt-4 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3">
      <p class="text-xs text-amber-700 leading-relaxed">
        Reservation fee is non-refundable once verified and processed. If the payment does not match the required amount, the reservation may be rejected before requirement tracking.
      </p>
    </div>
  </section>

  <!-- SCHEDULE -->
  <section class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
    <div class="flex items-center gap-2 mb-4">
      <div class="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center">
        <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
        </svg>
      </div>
      <h3 class="text-sm font-bold text-slate-900 uppercase tracking-wide">Reservation Schedule</h3>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Move-in / Turnover Date</p>
        <p id="ef_movein" class="text-sm font-semibold text-slate-800 mt-1">-</p>
      </div>

      <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Move-out Date</p>
        <p id="ef_moveout" class="text-sm font-semibold text-slate-800 mt-1">-</p>
      </div>
    </div>
  </section>

  <!-- REQUIREMENT TRACKING -->
  <section id="requirementTrackingSection" class="bg-slate-50 border border-slate-200 rounded-2xl p-5 hidden">
    <div class="flex items-center gap-2 mb-5">
      <div class="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center">
        <svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5h6m-7 4h8m-8 4h5m-6 8h10a2 2 0 002-2V7.8a2 2 0 00-.6-1.4l-3.8-3.8A2 2 0 0013.2 2H7a2 2 0 00-2 2v15a2 2 0 002 2z"/>
        </svg>
      </div>
      <div>
        <h3 class="text-sm font-bold text-slate-900 uppercase tracking-wide">Requirement Tracking</h3>
        <p class="text-xs text-slate-500 mt-0.5">Only available after payment is verified.</p>
      </div>
    </div>

    <input type="hidden" id="process_reservation_id">

    <div id="requirementDecisionDisplay" class="hidden mb-5 rounded-xl border px-4 py-3">
      <p class="text-xs font-bold uppercase tracking-wide mb-1" id="requirementDecisionLabel">
        Requirement Status
      </p>
      <p class="text-sm font-semibold" id="requirementDecisionText">
        -
      </p>
    </div>
    
    <div id="requirementDecisionDisplay" class="hidden mb-5 rounded-xl border px-4 py-3">
  <p class="text-xs font-bold uppercase tracking-wide mb-1" id="requirementDecisionLabel">
    Requirement Status
  </p>
  <p class="text-sm font-semibold" id="requirementDecisionText">
    -
  </p>
</div>

<div id="requirementActionArea">
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <label class="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50">
        <input type="checkbox" id="check_two_valid_ids" class="requirement-check w-4 h-4 rounded border-slate-300 accent-slate-900">
        <span class="text-sm font-medium text-slate-700">Photocopy of 2 Valid IDs</span>
      </label>

      <label class="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50">
        <input type="checkbox" id="check_tin_number" class="requirement-check w-4 h-4 rounded border-slate-300 accent-slate-900">
        <span class="text-sm font-medium text-slate-700">TIN Number</span>
      </label>

      <label class="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50">
        <input type="checkbox" id="check_reservation_agreement" class="requirement-check w-4 h-4 rounded border-slate-300 accent-slate-900">
        <span class="text-sm font-medium text-slate-700">Reservation Agreement</span>
      </label>
    </div>

    <div class="mt-5 rounded-xl bg-blue-50 border border-blue-200 px-4 py-3">
      <p class="text-xs text-blue-700 leading-relaxed">
        This is admin tracking only. No document upload is required here.
      </p>
    </div>

    <button 
      type="button"
      id="btnSaveRequirements"
      class="mt-5 w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold px-4 py-3 rounded-xl transition-all">
      Save Requirement Tracking
    </button>
  </div>

  <button 
    type="button"
    id="btnEditRequirements"
    class="hidden mt-5 w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold px-4 py-3 rounded-xl transition-all">
    Edit Requirement Tracking
  </button>
    <div class="mt-4 bg-white border border-slate-200 rounded-xl p-4">
    <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Last Updated By</p>
    <p id="requirements_updated_by_display" class="text-sm font-semibold text-slate-800 mt-1">Not updated yet</p>
    <p id="requirements_updated_at_display" class="text-xs text-slate-500 mt-1">-</p>
  </div>
  </section>

  <!-- FOOTER -->
  <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50/60">
    <<button 
    type="button"
    id="btnRequestCancellation"
    class="btn-press px-5 py-2 text-sm font-bold text-red-600 border border-red-200 bg-red-50 rounded-xl hover:bg-red-100 transition-all active:scale-95">
    Request Cancellation
  </button>

  <button 
    type="button"
    onclick="closeEditModal()" 
    class="btn-press px-5 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-100 transition-all active:scale-95">
    Close
  </button>
  </div>
</div>
</div>

<!-- VERIFY PAYMENT CONFIRMATION MODAL -->
<div id="verifyPaymentModal" class="fixed inset-0 z-[70] hidden items-center justify-center bg-black/50 px-4">
  <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
    <div class="bg-emerald-600 px-6 py-4">
      <h2 class="text-lg font-bold text-white">Verify Payment?</h2>
      <p class="text-sm text-emerald-50 mt-1">Please confirm before proceeding.</p>
    </div>

    <div class="p-6">
      <p class="text-sm text-slate-700 leading-relaxed">
        Are you sure the uploaded payment proof matches the required reservation amount?
      </p>

      <div class="mt-4 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3">
        <p class="text-xs text-emerald-700 leading-relaxed">
          This will mark the payment as verified and notify the client to proceed with the reservation requirements.
        </p>
      </div>

      <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mt-5 mb-1.5">
        Admin Remarks / Notes
      </label>
      <textarea id="verifyPaymentRemarks" rows="3" placeholder="Optional notes..." class="zep-input w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-800 resize-none"></textarea>
    </div>

    <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50">
      <button type="button" onclick="closePaymentConfirmModal('verifyPaymentModal')" class="px-5 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-100">
        Cancel
      </button>

      <button type="button" onclick="confirmPaymentAction('verify')" class="px-5 py-2 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl">
        Yes, Verify Payment
      </button>
    </div>
  </div>
</div>


<!-- REJECT PAYMENT CONFIRMATION MODAL -->
<div id="rejectPaymentModal" class="fixed inset-0 z-[70] hidden items-center justify-center bg-black/50 px-4">
  <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
    <div class="bg-red-600 px-6 py-4">
      <h2 class="text-lg font-bold text-white">Reject Payment?</h2>
      <p class="text-sm text-red-50 mt-1">Please confirm before proceeding.</p>
    </div>

    <div class="p-6">
      <p class="text-sm text-slate-700 leading-relaxed">
        Are you sure the uploaded payment proof does not match the required reservation amount?
      </p>

      <div class="mt-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3">
        <p class="text-xs text-red-700 leading-relaxed">
          This will reject the reservation request, notify the client, and release the unit back to available status.
        </p>
      </div>

      <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mt-5 mb-1.5">
        Reason / Admin Remarks <span class="text-red-500">*</span>
      </label>
      <textarea id="rejectPaymentRemarks" rows="3" placeholder="Example: Submitted amount does not match the required reservation amount." class="zep-input w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-800 resize-none"></textarea>
    </div>

    <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50">
      <button type="button" onclick="closePaymentConfirmModal('rejectPaymentModal')" class="px-5 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-100">
        Cancel
      </button>

      <button type="button" onclick="confirmPaymentAction('reject')" class="px-5 py-2 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl">
        Yes, Reject Payment
      </button>
    </div>
  </div>
</div>

<!-- OWNER CANCELLATION REQUEST MODAL -->
<div id="ownerCancelRequestModal" class="fixed inset-0 z-[70] hidden items-center justify-center bg-black/50 px-4">
  <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
    <div class="bg-red-600 px-6 py-4">
      <h2 class="text-lg font-bold text-white">Request Cancellation?</h2>
      <p class="text-sm text-red-50 mt-1">Admin approval is required.</p>
    </div>

    <div class="p-6">
      <p class="text-sm text-slate-700 leading-relaxed">
        This will not cancel the reservation immediately. It will send a cancellation request to the admin for review.
      </p>

      <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mt-5 mb-1.5">
        Reason for Cancellation <span class="text-red-500">*</span>
      </label>

      <textarea 
        id="ownerCancelReason"
        rows="4"
        placeholder="Enter reason for requesting cancellation..."
        class="zep-input w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-800 resize-none"></textarea>
    </div>

    <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50">
      <button 
        type="button" 
        onclick="closeOwnerCancelRequestModal()" 
        class="px-5 py-2 text-sm font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-100">
        Close
      </button>

      <button 
        type="button" 
        onclick="submitOwnerCancelRequest()" 
        class="px-5 py-2 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl">
        Submit Request
      </button>
    </div>
  </div>
</div>
<script>
let sidebarCollapsed = false;
let editRow = null;

/* SIDEBAR */
function toggleCollapse() {
  sidebarCollapsed = !sidebarCollapsed;

  const sidebar = document.getElementById('sidebar');
  const mainWrapper = document.getElementById('mainWrapper');

  if (sidebar) sidebar.classList.toggle('collapsed', sidebarCollapsed);
  if (mainWrapper) mainWrapper.classList.toggle('sidebar-collapsed', sidebarCollapsed);
}

function openMobileSidebar() {
  document.getElementById('sidebar')?.classList.add('open');
  document.getElementById('overlay')?.classList.add('show');
}

function closeMobileSidebar() {
  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('overlay')?.classList.remove('show');
}

function toggleNotice() {
  document.getElementById('noticePanel')?.classList.toggle('open');
  document.getElementById('noticeChevron')?.classList.toggle('rotated');
}

/* PROFILE */
function toggleProfile() {
  const dropdown = document.getElementById('profileDropdown');
  const chevron = document.getElementById('profileChevron');

  if (!dropdown) return;

  dropdown.classList.toggle('hidden');

  if (chevron) {
    chevron.style.transform = dropdown.classList.contains('hidden') 
      ? 'rotate(0deg)' 
      : 'rotate(180deg)';
  }
}

document.addEventListener('click', function(e) {
  const profileWrapper = document.getElementById('profileWrapper');
  const profileBtn = e.target.closest('button[onclick="toggleProfile()"]');

  if (profileWrapper && !profileWrapper.contains(e.target) && !profileBtn) {
    document.getElementById('profileDropdown')?.classList.add('hidden');

    const chevron = document.getElementById('profileChevron');
    if (chevron) chevron.style.transform = 'rotate(0deg)';
  }
});

document.addEventListener('DOMContentLoaded', function() {
  const userName = '<?php echo htmlspecialchars($_SESSION["full_name"] ?? "Unit Owner"); ?>';
  const initials = '<?php echo $_SESSION["initial"] ?? "U"; ?>';

  const nameEl = document.getElementById('userName');
  const initialsEl = document.getElementById('userInitials');

  if (nameEl) nameEl.textContent = userName;
  if (initialsEl) initialsEl.textContent = initials;

  document.querySelectorAll('.requirement-check').forEach(check => {
    check.addEventListener('change', function() {
      // When owner edits a completed requirement set, allow saving again.
      updateRequirementLiveState();
    });
  });

  const editBtn = document.getElementById('btnEditRequirements');
  if (editBtn) {
    editBtn.addEventListener('click', function() {
      document.getElementById('requirementActionArea')?.classList.remove('hidden');
      document.getElementById('btnEditRequirements')?.classList.add('hidden');
    });
  }

  const saveBtn = document.getElementById('btnSaveRequirements');
  if (saveBtn) {
    saveBtn.addEventListener('click', saveRequirementTracking);
  }
});

/* LOGOUT */
function confirmLogout() {
  document.getElementById('logoutModal')?.classList.remove('hidden');
}

function hideModal() {
  document.getElementById('logoutModal')?.classList.add('hidden');
}

function doLogout() {
  window.location.href = '/Zeppelin-Suites/public/php_files/logout_session.php';
}

/* SEARCH */
function filterSearch() {
  const input = document.getElementById('searchInput');
  const q = input ? input.value.toLowerCase() : '';

  document.querySelectorAll('#resBody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

/* HELPERS */
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value || '-';
}

function setValue(id, value) {
  const el = document.getElementById(id);
  if (el) el.value = value || '';
}

/* OPEN VIEW MODAL */
function openEditModal(row) {
  editRow = row;

  const modal = document.getElementById('editModalBackdrop');
  if (!modal) return;

  const reservationStatus = row.dataset.reservationStatus || '';
  const paymentStatus = row.dataset.paymentStatus || '';

  setText('editModalMeta', `Reservation #${row.dataset.reservationId} • Inquiry #${row.dataset.inquiryId}`);

  setText('view_client_name', row.dataset.clientName);
  setText('view_unit', row.dataset.unit);

  setText('ef_name', row.dataset.clientName);
  setText('ef_email', row.dataset.clientEmail);
  setText('ef_contact', row.dataset.clientContact);
  setText('ef_inquiry_type', row.dataset.inquiryType);

  setText('ef_unit', row.dataset.unit);
  setText('ef_owner', row.dataset.ownerName);
  setText('ef_owner_email', row.dataset.ownerEmail);
  setText('ef_transaction_type', row.dataset.transactionType);
  setText('ef_reservation_type', row.dataset.reservationType);
  setText('ef_resident_type', row.dataset.residentType);

  setText('ef_movein', row.dataset.moveIn);
  setText('ef_moveout', row.dataset.moveOut || 'N/A');

  setText('ef_price_basis', row.dataset.priceBasis);
  setText('ef_payment_percentage', row.dataset.paymentPercentage);
  setText('ef_required_amount', row.dataset.requiredAmount);
  setText('ef_payment_method', row.dataset.paymentMethod);
  setText('ef_payment_reference', row.dataset.paymentReference);

  setText('view_payment_status', paymentStatus || 'Payment Status');
  setText('view_reservation_status', reservationStatus || 'Reservation Status');
  setText('verify_payment_status', paymentStatus || 'Pending Review');
  setText(
  'requirements_updated_by_display',
  `${row.dataset.requirementsUpdatedByName || 'Not updated yet'} (${row.dataset.requirementsUpdatedByRole || '-'})`
  );

  setText(
    'requirements_updated_at_display',
    row.dataset.requirementsUpdatedAt || '-'
  );

  const proofLink = document.getElementById('ef_payment_proof');

  if (proofLink) {
    if (row.dataset.paymentProof) {
      proofLink.href = row.dataset.paymentProof;
      proofLink.textContent = 'View Proof';
      proofLink.classList.remove('pointer-events-none', 'opacity-50');
    } else {
      proofLink.href = '#';
      proofLink.textContent = 'No Proof Uploaded';
      proofLink.classList.add('pointer-events-none', 'opacity-50');
    }
  }

  setValue('process_reservation_id', row.dataset.reservationId);

  const twoIds = document.getElementById('check_two_valid_ids');
  const tin = document.getElementById('check_tin_number');
  const agreement = document.getElementById('check_reservation_agreement');

  if (twoIds) twoIds.checked = row.dataset.twoValidIdsStatus === '1';
  if (tin) tin.checked = row.dataset.tinNumberStatus === '1';
  if (agreement) agreement.checked = row.dataset.reservationAgreementStatus === '1';

  updatePaymentDecisionUI(paymentStatus);
  updateRequirementSectionUI(paymentStatus, reservationStatus);

  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

/* CLOSE MODAL */
function closeEditModal() {
  const modal = document.getElementById('editModalBackdrop');

  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }

  editRow = null;
}

document.addEventListener('keydown', function(event) {
  if (event.key === 'Escape') {
    closeEditModal();
  }
});

document.getElementById('editModalBackdrop')?.addEventListener('click', function(event) {
  if (event.target === this) {
    closeEditModal();
  }
});

/* PAYMENT UI - VIEW ONLY FOR UNIT OWNER */
function updatePaymentDecisionUI(paymentStatus) {
  const status = (paymentStatus || '').toLowerCase();

  const display = document.getElementById('paymentDecisionDisplay');
  const label = document.getElementById('paymentDecisionLabel');
  const text = document.getElementById('paymentDecisionText');

  if (!display || !label || !text) return;

  display.className = 'hidden mt-5 rounded-xl border px-4 py-3';

  if (status === 'verified') {
    display.classList.remove('hidden');
    display.classList.add('bg-emerald-50', 'border-emerald-200');

    label.className = 'text-xs font-bold uppercase tracking-wide mb-1 text-emerald-700';
    text.className = 'text-sm font-semibold text-emerald-800';

    label.textContent = 'Payment Verified';
    text.textContent = 'HOA/Admin has verified the payment. Requirement tracking is now available.';
    return;
  }

  if (status === 'rejected') {
    display.classList.remove('hidden');
    display.classList.add('bg-red-50', 'border-red-200');

    label.className = 'text-xs font-bold uppercase tracking-wide mb-1 text-red-700';
    text.className = 'text-sm font-semibold text-red-800';

    label.textContent = 'Payment Rejected';
    text.textContent = 'HOA/Admin rejected this payment. Requirement tracking is not available.';
    return;
  }

  display.classList.remove('hidden');
  display.classList.add('bg-amber-50', 'border-amber-200');

  label.className = 'text-xs font-bold uppercase tracking-wide mb-1 text-amber-700';
  text.className = 'text-sm font-semibold text-amber-800';

  label.textContent = 'Payment Pending Review';
  text.textContent = 'HOA/Admin has not verified the payment yet. Requirement tracking is locked.';
}

/* REQUIREMENT UI */
function updateRequirementSectionUI(paymentStatus, reservationStatus) {
  const payment = (paymentStatus || '').toLowerCase();
  const status = (reservationStatus || '').toLowerCase();

  const section = document.getElementById('requirementTrackingSection');
  const actionArea = document.getElementById('requirementActionArea');
  const display = document.getElementById('requirementDecisionDisplay');
  const label = document.getElementById('requirementDecisionLabel');
  const text = document.getElementById('requirementDecisionText');
  const editBtn = document.getElementById('btnEditRequirements');

  if (!section || !actionArea || !display || !label || !text || !editBtn) return;

  display.className = 'hidden mb-5 rounded-xl border px-4 py-3';

  if (payment !== 'verified') {
    section.classList.add('hidden');
    return;
  }

  section.classList.remove('hidden');

  if (status === 'requirements completed') {
    actionArea.classList.add('hidden');
    editBtn.classList.remove('hidden');

    display.classList.remove('hidden');
    display.classList.add('bg-emerald-50', 'border-emerald-200');

    label.className = 'text-xs font-bold uppercase tracking-wide mb-1 text-emerald-700';
    text.className = 'text-sm font-semibold text-emerald-800';

    label.textContent = 'Requirements Completed';
    text.textContent = 'All reservation requirements have been completed. You may edit tracking if needed.';
    return;
  }

  if (status === 'reserved') {
    actionArea.classList.add('hidden');
    editBtn.classList.add('hidden');

    display.classList.remove('hidden');
    display.classList.add('bg-emerald-50', 'border-emerald-200');

    label.className = 'text-xs font-bold uppercase tracking-wide mb-1 text-emerald-700';
    text.className = 'text-sm font-semibold text-emerald-800';

    label.textContent = 'Officially Booked';
    text.textContent = 'This reservation is already officially booked.';
    return;
  }

  actionArea.classList.remove('hidden');
  editBtn.classList.add('hidden');
  display.classList.add('hidden');
}

function updateRequirementLiveState() {
  const status = (editRow?.dataset?.reservationStatus || '').toLowerCase();

  if (status === 'reserved') return;

  const actionArea = document.getElementById('requirementActionArea');
  const editBtn = document.getElementById('btnEditRequirements');

  if (actionArea) actionArea.classList.remove('hidden');
  if (editBtn) editBtn.classList.add('hidden');
}

/* SAVE REQUIREMENTS - UNIT OWNER ONLY */
function saveRequirementTracking() {
  const reservationId = document.getElementById('process_reservation_id')?.value;

  if (!reservationId) {
    alert('Reservation ID not found.');
    return;
  }

  const formData = new FormData();
  formData.append('reservation_id', reservationId);
  formData.append('two_valid_ids_status', document.getElementById('check_two_valid_ids')?.checked ? '1' : '0');
  formData.append('tin_number_status', document.getElementById('check_tin_number')?.checked ? '1' : '0');
  formData.append('reservation_agreement_status', document.getElementById('check_reservation_agreement')?.checked ? '1' : '0');

  fetch('ActionsUOP/updateOwnerRequirementStatus.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);

    if (data.success) {
      window.location.reload();
    }
  })
  .catch(error => {
    console.error(error);
    alert('Something went wrong while saving requirement tracking.');
  });
}

function openOwnerCancelRequestModal() {
  const reservationId = document.getElementById('process_reservation_id')?.value;

  if (!reservationId) {
    alert('Reservation ID not found.');
    return;
  }

  const reasonBox = document.getElementById('ownerCancelReason');
  const modal = document.getElementById('ownerCancelRequestModal');

  if (reasonBox) reasonBox.value = '';

  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

function closeOwnerCancelRequestModal() {
  const modal = document.getElementById('ownerCancelRequestModal');

  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

function submitOwnerCancelRequest() {
  const reservationId = document.getElementById('process_reservation_id')?.value;
  const reason = document.getElementById('ownerCancelReason')?.value.trim();

  if (!reservationId) {
    alert('Reservation ID not found.');
    return;
  }

  if (!reason) {
    alert('Cancellation reason is required.');
    return;
  }

  const formData = new FormData();
  formData.append('reservation_id', reservationId);
  formData.append('reason', reason);

  fetch('ActionsUOP/requestCancellation.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);

    if (data.success) {
      window.location.reload();
    }
  })
  .catch(error => {
    console.error(error);
    alert('Something went wrong while requesting cancellation.');
  });
}

document.getElementById('btnRequestCancellation')?.addEventListener('click', openOwnerCancelRequestModal);
</script>
</body>
</html>